package com.codacy.analysis.core.files

class GitFileCollectorSpec extends FileCollectorSpec(new GitFileCollector())
